<template>
  <h2>我是About的内容</h2>
</template>

<script>
export default {
  name: "About",
  // mounted() {
  //   console.log('Home组件挂载完毕', this);
  //   window.aboutRoute = this.$route;
  //   window.aboutRouter = this.$router;
  // },
  // beforeDestroy() {
  //   console.log('About组件即将被销毁');
  // }
}
</script>

<style scoped>

</style>
